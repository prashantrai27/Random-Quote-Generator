# Random-Quotes-Project
A small JavaScript project that changes the quote and author on the click of a button.
