const quotes = [
    {
        quote: "We are what our thoughts have made us; so take care about what you think. Words are secondary. Thoughts live; they travel far.",
        author: "Swami Vivekananda"
    },
    {
        quote: "The person who talks most of his own virtue is often the least virtuous.",
        author: "Jawaharlal Nehru"
    },
    {
        quote: "Life is a song - sing it. Life is a game - play it. Life is a challenge - meet it. Life is a dream - realize it. Life is a sacrifice - offer it. Life is love - enjoy it.",
        author: "Sai Baba"
    },
    {
        quote:"Look up at the stars and not down at your feet. Try to make sense of what you see, and wonder about what makes the universe exist. Be curious.",
        author: "Stephan hawkings"
    },
    {
        quote:"It always seems impossible until it's done.",
        author:"Nelson Mandela"
    },
    {
        quote:"If you're going through hell, keep going.",
        author:"Winston Churchill"
    },
    {
        quote:"We should not give up and we should not allow the problem to defeat us.",
        author:"A.P.J. Abdul Kalam"
    },
    {
        quote:"I know where I'm going and I know the truth, and I don't have to be what you want me to be. I'm free to be what I want.",
        author:"Muhammad Ali"
    }
];

var btn = document.getElementById("generate-btn");

btn.addEventListener("click",function(){
    let random = Math.floor(Math.random() * quotes.length);

    document.getElementById("quote").textContent = quotes[random].quote;
    document.querySelector(".author").textContent = quotes[random].author;
})